package Algorithm_class;

import java.io.*;
import java.util.StringTokenizer;

public class KnapsackDFS {

    static int n;
    static int W;
    static int[] weights;
    static int[] values;
    static int[] include;
    static int[] bestset;
    static int maxprofit = 0;
    static int count = 0;
    static int noncount = 0;

    public static void main(String[] args) throws IOException {
        File file = new File("E:\\sample5.txt");
        FileReader fr = new FileReader(file);
        BufferedReader br = new BufferedReader(fr);
        StringTokenizer st = new StringTokenizer(br.readLine());
        n = Integer.parseInt(st.nextToken());
        W = Integer.parseInt(st.nextToken());

        weights = new int[n + 1];
        values = new int[n + 1];
        include = new int[n + 1];
        bestset = new int[n + 1];
        st = new StringTokenizer(br.readLine());
        for (int i = 1; i <= n; i++) weights[i] = Integer.parseInt(st.nextToken());
        st = new StringTokenizer(br.readLine());
        for (int i = 1; i <= n; i++) values[i] = Integer.parseInt(st.nextToken());

        knapsack(0, 0, 0);

        for(int i = 1 ; i <=n;i++) System.out.print(bestset[i] + " ");
        System.out.println("\nThe answer: $" + maxprofit);
        System.out.println(count + " " + noncount);
    }

    public static void knapsack(int i, int currentProfit, int currentWeight) {
        count++;
        if (currentWeight <= W && currentProfit > maxprofit) {
            maxprofit = currentProfit;
            System.arraycopy(include, 0, bestset, 0, n + 1);
        }

        if (promising(i, currentProfit, currentWeight)) {
            include[i + 1] = 1;
            knapsack(i + 1, currentProfit + values[i + 1], currentWeight + weights[i + 1]);
            include[i + 1] = 0;
            knapsack(i + 1, currentProfit, currentWeight);
        }else noncount++;
    }

    public static boolean promising(int i, int profit, int weight) {
        int j, k;
        int totweight;
        float bound;

        if (weight >= W) {
            return false;
        } else {
            j = i + 1;
            bound = (float) profit;
            totweight = weight;

            while (j <= n && totweight + weights[j] <= W) {
                totweight = totweight + weights[j];
                bound = bound + values[j];
                j++;
            }

            k = j;
            if (k <= n) bound = bound + (W - totweight) * ((float) values[k] / weights[k]);

            return (bound > maxprofit);
        }
    }
}
